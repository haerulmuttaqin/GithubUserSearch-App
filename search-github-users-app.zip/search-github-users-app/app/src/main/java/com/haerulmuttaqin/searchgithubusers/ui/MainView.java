package com.haerulmuttaqin.searchgithubusers.ui;

import com.haerulmuttaqin.searchgithubusers.model.Items;

import java.util.List;

public interface MainView {

    interface InitView {

        void showLoading();
        void hideLoading();
        void userList(List<Items> users);
        void userListFailure(String errorMessage, String keyword);

    }

    interface GetUsers { void getUserList(String keyword); }
}
